/*
-----------------------------------------------------------------------
Copyright: 2010-2022, imec Vision Lab, University of Antwerp
           2014-2022, CWI, Amsterdam

Contact: astra@astra-toolbox.com
Website: http://www.astra-toolbox.com/

This file is part of the ASTRA Toolbox.


The ASTRA Toolbox is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The ASTRA Toolbox is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the ASTRA Toolbox. If not, see <http://www.gnu.org/licenses/>.

-----------------------------------------------------------------------
*/

#include "astra/ParallelProjectionGeometry2D.h"

#include "astra/GeometryUtil2D.h"
#include "astra/XMLConfig.h"

#include <cstring>

using namespace std;

namespace astra
{

//----------------------------------------------------------------------------------------
// Default constructor.
CParallelProjectionGeometry2D::CParallelProjectionGeometry2D()
{

}

//----------------------------------------------------------------------------------------
// Constructor.
CParallelProjectionGeometry2D::CParallelProjectionGeometry2D(int _iProjectionAngleCount,
                                                             int _iDetectorCount,
                                                             float32 _fDetectorWidth,
                                                             std::vector<float32> &&_pfProjectionAngles)
	: CParallelProjectionGeometry2D()
{
	initialize(_iProjectionAngleCount,
	           _iDetectorCount, 
	           _fDetectorWidth, 
	           std::move(_pfProjectionAngles));
}

//---------------------------------------------------------------------------------------
// Initialize - Config
bool CParallelProjectionGeometry2D::initialize(const Config& _cfg)
{
	assert(!m_bInitialized);

	ConfigReader<CProjectionGeometry2D> CR("ParallelProjectionGeometry2D", this, _cfg);	


	// initialization of parent class
	if (!CProjectionGeometry2D::initialize(_cfg))
		return false;

	// success
	m_bInitialized = _check();
	return m_bInitialized;
}

//----------------------------------------------------------------------------------------
// Initialization.
bool CParallelProjectionGeometry2D::initialize(int _iProjectionAngleCount, 
                                               int _iDetectorCount, 
                                               float32 _fDetectorWidth, 
                                               std::vector<float32> &&_pfProjectionAngles)
{
	assert(!m_bInitialized);

	_initialize(_iProjectionAngleCount,
	            _iDetectorCount,
	            _fDetectorWidth,
	            std::move(_pfProjectionAngles));

	// success
	m_bInitialized = _check();
	return m_bInitialized;
}

//----------------------------------------------------------------------------------------
// Clone
CProjectionGeometry2D* CParallelProjectionGeometry2D::clone() const
{
	return new CParallelProjectionGeometry2D(*this);
}

//----------------------------------------------------------------------------------------
// is equal
bool CParallelProjectionGeometry2D::isEqual(const CProjectionGeometry2D &_pGeom2) const
{
	// try to cast argument to CParallelProjectionGeometry2D
	const CParallelProjectionGeometry2D* pGeom2 = dynamic_cast<const CParallelProjectionGeometry2D*>(&_pGeom2);
	if (pGeom2 == NULL) return false;

	// both objects must be initialized
	if (!m_bInitialized || !pGeom2->m_bInitialized) return false;

	// check all values
	if (m_iProjectionAngleCount != pGeom2->m_iProjectionAngleCount) return false;
	if (m_iDetectorCount != pGeom2->m_iDetectorCount) return false;
	if (m_fDetectorWidth != pGeom2->m_fDetectorWidth) return false;
	
	for (int i = 0; i < m_iProjectionAngleCount; ++i) {
	//	if (m_pfProjectionAngles[i] != pGeom2->m_pfProjectionAngles[i]) return false;
	}

	return true;
}

//----------------------------------------------------------------------------------------
// Get the configuration object
Config* CParallelProjectionGeometry2D::getConfiguration() const 
{
	ConfigWriter CW("ProjectionGeometry2D", "parallel");

	CW.addInt("DetectorCount", getDetectorCount());
	CW.addNumerical("DetectorWidth", getDetectorWidth());
	CW.addNumericalArray("ProjectionAngles", &m_pfProjectionAngles[0], m_iProjectionAngleCount);

	return CW.getConfig();
}

//----------------------------------------------------------------------------------------
CParallelVecProjectionGeometry2D* CParallelProjectionGeometry2D::toVectorGeometry()
{
	std::vector<SParProjection> vectors = genParProjections(m_iProjectionAngleCount,
	                                            m_iDetectorCount,
	                                            m_fDetectorWidth,
	                                            &m_pfProjectionAngles[0], 0);
	return new CParallelVecProjectionGeometry2D(m_iProjectionAngleCount, m_iDetectorCount, std::move(vectors));
}

} // end namespace astra
