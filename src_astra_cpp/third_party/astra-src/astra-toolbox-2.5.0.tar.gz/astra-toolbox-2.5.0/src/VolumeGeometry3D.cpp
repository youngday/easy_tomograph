/*
-----------------------------------------------------------------------
Copyright: 2010-2022, imec Vision Lab, University of Antwerp
           2014-2022, CWI, Amsterdam

Contact: astra@astra-toolbox.com
Website: http://www.astra-toolbox.com/

This file is part of the ASTRA Toolbox.


The ASTRA Toolbox is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The ASTRA Toolbox is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the ASTRA Toolbox. If not, see <http://www.gnu.org/licenses/>.

-----------------------------------------------------------------------
*/

#include "astra/VolumeGeometry3D.h"
#include "astra/XMLConfig.h"
#include "astra/Logging.h"

namespace astra
{

//----------------------------------------------------------------------------------------
// Check all variable values
bool CVolumeGeometry3D::_check()
{
	ASTRA_CONFIG_CHECK(m_iGridColCount > 0, "VolumeGeometry3D", "GridColCount must be strictly positive.");
	ASTRA_CONFIG_CHECK(m_iGridRowCount > 0, "VolumeGeometry3D", "GridRowCount must be strictly positive.");
	ASTRA_CONFIG_CHECK(m_iGridSliceCount > 0, "VolumeGeometry3D", "GridSliceCount must be strictly positive.");
	ASTRA_CONFIG_CHECK(m_fWindowMinX < m_fWindowMaxX, "VolumeGeometry3D", "WindowMinX should be lower than WindowMaxX.");
	ASTRA_CONFIG_CHECK(m_fWindowMinY < m_fWindowMaxY, "VolumeGeometry3D", "WindowMinY should be lower than WindowMaxY.");
	ASTRA_CONFIG_CHECK(m_fWindowMinZ < m_fWindowMaxZ, "VolumeGeometry3D", "WindowMinZ should be lower than WindowMaxZ.");

	ASTRA_CONFIG_CHECK(m_iGridTotCount == ((size_t)m_iGridColCount * m_iGridRowCount * m_iGridSliceCount), "VolumeGeometry3D", "Internal configuration error.");
#if 0
	ASTRA_CONFIG_CHECK(m_fWindowLengthX == (m_fWindowMaxX - m_fWindowMinX), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fWindowLengthY == (m_fWindowMaxY - m_fWindowMinY), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fWindowLengthZ == (m_fWindowMaxZ - m_fWindowMinZ), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fWindowArea == (m_fWindowLengthX * m_fWindowLengthY *  m_fWindowLengthZ), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fPixelLengthX == (m_fWindowLengthX / (float32)m_iGridColCount), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fPixelLengthY == (m_fWindowLengthY / (float32)m_iGridRowCount), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fPixelLengthZ == (m_fWindowLengthZ / (float32)m_iGridSliceCount), "VolumeGeometry3D", "Internal configuration error.");

	ASTRA_CONFIG_CHECK(m_fPixelArea == (m_fPixelLengthX * m_fPixelLengthY * m_fPixelLengthZ), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fDivPixelLengthX == (1.0f / m_fPixelLengthX), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fDivPixelLengthY == (1.0f / m_fPixelLengthY), "VolumeGeometry3D", "Internal configuration error.");
	ASTRA_CONFIG_CHECK(m_fDivPixelLengthZ == (1.0f / m_fPixelLengthZ), "VolumeGeometry3D", "Internal configuration error.");
#endif

	return true;
}

//----------------------------------------------------------------------------------------
// Default constructor.
CVolumeGeometry3D::CVolumeGeometry3D()
	: m_bInitialized(false),
	  m_iGridColCount(0),
	  m_iGridRowCount(0),
	  m_iGridSliceCount(0),
	  m_iGridTotCount(0),
	  m_fWindowLengthX(0.0f),
	  m_fWindowLengthY(0.0f),
	  m_fWindowLengthZ(0.0f),
	  m_fWindowArea(0.0f),
	  m_fPixelLengthX(0.0f),
	  m_fPixelLengthY(0.0f),
	  m_fPixelLengthZ(0.0f),
	  m_fPixelArea(0.0f),
	  m_fDivPixelLengthX(0.0f),
	  m_fDivPixelLengthY(0.0f),
	  m_fDivPixelLengthZ(0.0f),
	  m_fWindowMinX(0.0f),
	  m_fWindowMinY(0.0f),
	  m_fWindowMinZ(0.0f),
	  m_fWindowMaxX(0.0f),
	  m_fWindowMaxY(0.0f),
	  m_fWindowMaxZ(0.0f),
	  configCheckData(nullptr)
{

}

//----------------------------------------------------------------------------------------
// Default constructor
CVolumeGeometry3D::CVolumeGeometry3D(int _iGridColCount, int _iGridRowCount, int _iGridSliceCount)
	: CVolumeGeometry3D()
{
	initialize(_iGridColCount, _iGridRowCount, _iGridSliceCount);
}

//----------------------------------------------------------------------------------------
// Constructor.
CVolumeGeometry3D::CVolumeGeometry3D(int _iGridColCount, 
									 int _iGridRowCount, 
									 int _iGridSliceCount, 
									 float32 _fWindowMinX, 
									 float32 _fWindowMinY,
									 float32 _fWindowMinZ,
									 float32 _fWindowMaxX,
									 float32 _fWindowMaxY,
									 float32 _fWindowMaxZ)
	: CVolumeGeometry3D()
{
	initialize(_iGridColCount, 
			   _iGridRowCount, 
			   _iGridSliceCount, 
			   _fWindowMinX, 
			   _fWindowMinY, 
			   _fWindowMinZ, 
			   _fWindowMaxX, 
			   _fWindowMaxY,
			   _fWindowMaxZ);
}

//----------------------------------------------------------------------------------------
// Destructor.
CVolumeGeometry3D::~CVolumeGeometry3D()
{

}

//----------------------------------------------------------------------------------------
// Initialization with a Config object
bool CVolumeGeometry3D::initialize(const Config& _cfg)
{
	assert(!m_bInitialized);

	ConfigReader<CVolumeGeometry3D> CR("VolumeGeometry3D", this, _cfg);

	bool ok = true;

	// Required: number of voxels
	ok &= CR.getRequiredInt("GridColCount", m_iGridColCount);
	ok &= CR.getRequiredInt("GridRowCount", m_iGridRowCount);
	ok &= CR.getRequiredInt("GridSliceCount", m_iGridSliceCount);

	// Optional: window minima and maxima
	ok &= CR.getOptionNumerical("WindowMinX", m_fWindowMinX, -m_iGridColCount/2.0f);
	ok &= CR.getOptionNumerical("WindowMaxX", m_fWindowMaxX, m_iGridColCount/2.0f);
	ok &= CR.getOptionNumerical("WindowMinY", m_fWindowMinY, -m_iGridRowCount/2.0f);
	ok &= CR.getOptionNumerical("WindowMaxY", m_fWindowMaxY, m_iGridRowCount/2.0f);
	ok &= CR.getOptionNumerical("WindowMinZ", m_fWindowMinZ, -m_iGridSliceCount/2.0f);
	ok &= CR.getOptionNumerical("WindowMaxZ", m_fWindowMaxZ, m_iGridSliceCount/2.0f);

	if (!ok)
		return false;

	// calculate some other things
	m_iGridTotCount = ((size_t)m_iGridColCount * m_iGridRowCount * m_iGridSliceCount);
	m_fWindowLengthX = (m_fWindowMaxX - m_fWindowMinX);
	m_fWindowLengthY = (m_fWindowMaxY - m_fWindowMinY);
	m_fWindowLengthZ = (m_fWindowMaxZ - m_fWindowMinZ);
	m_fWindowArea = (m_fWindowLengthX * m_fWindowLengthY *  m_fWindowLengthZ);
	m_fPixelLengthX = (m_fWindowLengthX / (float32)m_iGridColCount);
	m_fPixelLengthY = (m_fWindowLengthY / (float32)m_iGridRowCount);
	m_fPixelLengthZ = (m_fWindowLengthZ / (float32)m_iGridSliceCount);

	m_fPixelArea = (m_fPixelLengthX * m_fPixelLengthY * m_fPixelLengthZ);
    m_fDivPixelLengthX = ((float32)m_iGridColCount / m_fWindowLengthX); // == (1.0f / m_fPixelLengthX);
	m_fDivPixelLengthY = ((float32)m_iGridRowCount / m_fWindowLengthY); // == (1.0f / m_fPixelLengthY);
	m_fDivPixelLengthZ = ((float32)m_iGridSliceCount / m_fWindowLengthZ); // == (1.0f / m_fPixelLengthZ);

	// success
	m_bInitialized = _check();
	return m_bInitialized;
}

//----------------------------------------------------------------------------------------
// Initialization.
bool CVolumeGeometry3D::initialize(int _iGridColCount, int _iGridRowCount, int _iGridSliceCount)
{
	return initialize(_iGridColCount, 
					  _iGridRowCount, 
					  _iGridSliceCount, 
					  -_iGridColCount/2.0f,
					  -_iGridRowCount/2.0f,
					  -_iGridSliceCount/2.0f,
					  _iGridColCount/2.0f,
					  _iGridRowCount/2.0f,
					  _iGridSliceCount/2.0f);
}

//----------------------------------------------------------------------------------------
// Initialization.
bool CVolumeGeometry3D::initialize(int _iGridColCount, 
								   int _iGridRowCount, 
								   int _iGridSliceCount,
								   float32 _fWindowMinX, 
								   float32 _fWindowMinY, 
								   float32 _fWindowMinZ, 
								   float32 _fWindowMaxX, 
								   float32 _fWindowMaxY,
								   float32 _fWindowMaxZ)
{
	assert(!m_bInitialized);

	m_iGridColCount = _iGridColCount;
	m_iGridRowCount = _iGridRowCount;
	m_iGridSliceCount = _iGridSliceCount;
	m_iGridTotCount = ((size_t)m_iGridColCount * m_iGridRowCount * m_iGridSliceCount);

	m_fWindowMinX = _fWindowMinX;
	m_fWindowMinY = _fWindowMinY;
	m_fWindowMinZ = _fWindowMinZ;
	m_fWindowMaxX = _fWindowMaxX;
	m_fWindowMaxY = _fWindowMaxY;
	m_fWindowMaxZ = _fWindowMaxZ;

	m_fWindowLengthX = (m_fWindowMaxX - m_fWindowMinX);
	m_fWindowLengthY = (m_fWindowMaxY - m_fWindowMinY);
	m_fWindowLengthZ = (m_fWindowMaxZ - m_fWindowMinZ);
	m_fWindowArea = (m_fWindowLengthX * m_fWindowLengthY * m_fWindowLengthZ);

	m_fPixelLengthX = (m_fWindowLengthX / (float32)m_iGridColCount);
	m_fPixelLengthY = (m_fWindowLengthY / (float32)m_iGridRowCount);
	m_fPixelLengthZ = (m_fWindowLengthZ / (float32)m_iGridSliceCount);
	m_fPixelArea = (m_fPixelLengthX * m_fPixelLengthY);

    m_fDivPixelLengthX = ((float32)m_iGridColCount / m_fWindowLengthX); // == (1.0f / m_fPixelLengthX);
	m_fDivPixelLengthY = ((float32)m_iGridRowCount / m_fWindowLengthY); // == (1.0f / m_fPixelLengthY);
	m_fDivPixelLengthZ = ((float32)m_iGridSliceCount / m_fWindowLengthZ); // == (1.0f / m_fPixelLengthZ);

	m_bInitialized = _check();
	return m_bInitialized;
}

//----------------------------------------------------------------------------------------
// Clone
CVolumeGeometry3D* CVolumeGeometry3D::clone() const
{
	return new CVolumeGeometry3D(*this);
}

//----------------------------------------------------------------------------------------
// is of type
bool CVolumeGeometry3D::isEqual(const CVolumeGeometry3D* _pGeom2) const
{
	if (_pGeom2 == NULL) return false;

	// both objects must be initialized
	if (!m_bInitialized || !_pGeom2->m_bInitialized) return false;

	// check all values
	if (m_iGridColCount != _pGeom2->m_iGridColCount) return false;
	if (m_iGridRowCount != _pGeom2->m_iGridRowCount) return false;
	if (m_iGridSliceCount != _pGeom2->m_iGridSliceCount) return false;
	if (m_iGridTotCount != _pGeom2->m_iGridTotCount) return false;
	if (m_fWindowLengthX != _pGeom2->m_fWindowLengthX) return false;
	if (m_fWindowLengthY != _pGeom2->m_fWindowLengthY) return false;
	if (m_fWindowLengthZ != _pGeom2->m_fWindowLengthZ) return false;
	if (m_fWindowArea != _pGeom2->m_fWindowArea) return false;
	if (m_fPixelLengthX != _pGeom2->m_fPixelLengthX) return false;
	if (m_fPixelLengthY != _pGeom2->m_fPixelLengthY) return false;
	if (m_fPixelLengthZ != _pGeom2->m_fPixelLengthZ) return false;
	if (m_fPixelArea != _pGeom2->m_fPixelArea) return false;
	if (m_fDivPixelLengthX != _pGeom2->m_fDivPixelLengthX) return false;
	if (m_fDivPixelLengthY != _pGeom2->m_fDivPixelLengthY) return false;
	if (m_fDivPixelLengthZ != _pGeom2->m_fDivPixelLengthZ) return false;
	if (m_fWindowMinX != _pGeom2->m_fWindowMinX) return false;
	if (m_fWindowMinY != _pGeom2->m_fWindowMinY) return false;
	if (m_fWindowMinZ != _pGeom2->m_fWindowMinZ) return false;
	if (m_fWindowMaxX != _pGeom2->m_fWindowMaxX) return false;
	if (m_fWindowMaxY != _pGeom2->m_fWindowMaxY) return false;
	if (m_fWindowMaxZ != _pGeom2->m_fWindowMaxZ) return false;
	
	return true;
}

CVolumeGeometry2D * CVolumeGeometry3D::createVolumeGeometry2D() const
{
	CVolumeGeometry2D * pOutput = new CVolumeGeometry2D();
	pOutput->initialize(getGridColCount(), getGridRowCount());
	return pOutput;
}

//----------------------------------------------------------------------------------------
// Get the configuration object
Config* CVolumeGeometry3D::getConfiguration() const 
{
	ConfigWriter CW("VolumeGeometry3D");

	CW.addInt("GridColCount", m_iGridColCount);
	CW.addInt("GridRowCount", m_iGridRowCount);
	CW.addInt("GridSliceCount", m_iGridSliceCount);
	CW.addOptionNumerical("WindowMinX", m_fWindowMinX);
	CW.addOptionNumerical("WindowMaxX", m_fWindowMaxX);
	CW.addOptionNumerical("WindowMinY", m_fWindowMinY);
	CW.addOptionNumerical("WindowMaxY", m_fWindowMaxY);
	CW.addOptionNumerical("WindowMinZ", m_fWindowMinZ);
	CW.addOptionNumerical("WindowMaxZ", m_fWindowMaxZ);

	return CW.getConfig();
}
//----------------------------------------------------------------------------------------


//----------------------------------------------------------------------------------------

} // namespace astra
