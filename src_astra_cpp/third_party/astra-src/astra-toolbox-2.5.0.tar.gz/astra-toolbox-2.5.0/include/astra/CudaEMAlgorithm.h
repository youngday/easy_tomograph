/*
-----------------------------------------------------------------------
Copyright: 2010-2022, imec Vision Lab, University of Antwerp
           2014-2022, CWI, Amsterdam

Contact: astra@astra-toolbox.com
Website: http://www.astra-toolbox.com/

This file is part of the ASTRA Toolbox.


The ASTRA Toolbox is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The ASTRA Toolbox is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the ASTRA Toolbox. If not, see <http://www.gnu.org/licenses/>.

-----------------------------------------------------------------------
*/

#ifndef _INC_ASTRA_CUDAEMALGORITHM
#define _INC_ASTRA_CUDAEMALGORITHM

#include "Globals.h"
#include "Config.h"

#include "CudaReconstructionAlgorithm2D.h"

#ifdef ASTRA_CUDA

namespace astra {

class _AstraExport CCudaEMAlgorithm : public CCudaReconstructionAlgorithm2D
{
	
public:
	
	// type of the algorithm, needed to register with CAlgorithmFactory
	static inline const char* const type = "EM_CUDA";
	
	/** Default constructor, containing no code.
	 */
	CCudaEMAlgorithm();
	
	/** Destructor.
	 */
	virtual ~CCudaEMAlgorithm();

	/** Initialize the algorithm with a config object.
	 *
	 * @param _cfg Configuration Object
	 * @return initialization successful?
	 */
	virtual bool initialize(const Config& _cfg);

	/** Initialize class.
	 *
	 * @param _pProjector		Projector Object. (Optional)
	 * @param _pSinogram		ProjectionData2D object containing the sinogram data.
	 * @param _pReconstruction	VolumeData2D object for storing the reconstructed volume.
	 */
	bool initialize(CProjector2D* _pProjector,
	                CFloat32ProjectionData2D* _pSinogram,
	                CFloat32VolumeData2D* _pReconstruction);

	/** Get a description of the class.
	 *
	 * @return description string
	 */
	virtual std::string description() const;

	virtual bool run(int _iNrIterations);

	virtual bool getResidualNorm(float32& _fNorm);
protected:
	bool allocateBuffers();
	void freeBuffers();

	bool precomputeWeights();

	bool m_bBuffersInitialized;

	// Input/output buffers (on device)
	CData2D *D_projData;
	CData2D *D_volData;

	// Precomputed weight buffers (on device)
	CData2D *D_pixelWeight;

	// Temporary buffers (on device)
	CData2D *D_tmpProjData;
	CData2D *D_tmpVolData;
};

// inline functions
inline std::string CCudaEMAlgorithm::description() const { return CCudaEMAlgorithm::type; };

} // end namespace

#endif // ASTRA_CUDA

#endif 
