/*
-----------------------------------------------------------------------
Copyright: 2010-2022, imec Vision Lab, University of Antwerp
           2014-2022, CWI, Amsterdam

Contact: astra@astra-toolbox.com
Website: http://www.astra-toolbox.com/

This file is part of the ASTRA Toolbox.


The ASTRA Toolbox is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The ASTRA Toolbox is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the ASTRA Toolbox. If not, see <http://www.gnu.org/licenses/>.

-----------------------------------------------------------------------
*/

#ifndef _CUDA_ARITH3D_H
#define _CUDA_ARITH3D_H

#include "astra/cuda/stream.h"

namespace astraCUDA3d {

using astraCUDA::Stream;
using astraCUDA::automatic_sync;

struct opAddScaled;
struct opScaleAndAdd;
struct opAddMulScaled;
struct opAddMul;
struct opAdd;
struct opMul;
struct opMul2;
struct opDividedBy;
struct opInvert;
struct opSet;
struct opClampMin;
struct opClampMax;


template<typename op> bool processVol3D(astra::CData3D *out, const Stream &stream = Stream(automatic_sync));
template<typename op> bool processVol3D(astra::CData3D *out, float fParam, const Stream &stream = Stream(automatic_sync));
template<typename op> bool processVol3D(astra::CData3D *out, const astra::CData3D *in, const Stream &stream = Stream(automatic_sync));
template<typename op> bool processVol3D(astra::CData3D *out, const astra::CData3D *in, float fParam, const Stream &stream = Stream(automatic_sync));
template<typename op> bool processVol3D(astra::CData3D *out, const astra::CData3D *in1, const astra::CData3D *in2, float fParam, const Stream &stream = Stream(automatic_sync));
template<typename op> bool processVol3D(astra::CData3D *out, const astra::CData3D *in1, const astra::CData3D *in2, const Stream &stream = Stream(automatic_sync));


}

#endif
