/*
-----------------------------------------------------------------------
Copyright: 2010-2022, imec Vision Lab, University of Antwerp
           2014-2022, CWI, Amsterdam

Contact: astra@astra-toolbox.com
Website: http://www.astra-toolbox.com/

This file is part of the ASTRA Toolbox.


The ASTRA Toolbox is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

The ASTRA Toolbox is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with the ASTRA Toolbox. If not, see <http://www.gnu.org/licenses/>.

-----------------------------------------------------------------------
*/


#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>
#include <boost/test/auto_unit_test.hpp>
#include <boost/test/test_case_template.hpp>
#include <boost/test/floating_point_comparison.hpp>

#include "astra/ParallelProjectionGeometry2D.h"

BOOST_AUTO_TEST_CASE( testParallelProjectionGeometry2D_Constructor )
{
	std::vector<float> angles{ 0.0f, 1.0f, 2.0f, 3.0f };
	astra::CParallelProjectionGeometry2D geom(4, 8, 0.5f, std::move(angles));

	BOOST_REQUIRE( geom.isInitialized() );

	BOOST_CHECK( geom.getProjectionAngleCount() == 4 );
	BOOST_CHECK( geom.getDetectorCount() == 8 );
	BOOST_CHECK( geom.getDetectorWidth() == 0.5f );
	BOOST_CHECK( geom.getProjectionAngle(0) == 0.0f );
	BOOST_CHECK( geom.getProjectionAngle(1) == 1.0f );
	BOOST_CHECK( geom.getProjectionAngle(2) == 2.0f );
	BOOST_CHECK( geom.getProjectionAngle(3) == 3.0f );
	BOOST_CHECK( geom.getProjectionAngles()[0] == 0.0f );
	BOOST_CHECK( geom.getProjectionAngles()[3] == 3.0f );
}

BOOST_AUTO_TEST_CASE( testParallelProjectionGeometry2D_Offsets )
{
	std::vector<float> angles{ 0.0f, 1.0f, 2.0f, 3.0f };
	astra::CParallelProjectionGeometry2D geom(4, 8, 0.5f, std::move(angles));

	BOOST_REQUIRE( geom.isInitialized() );

	BOOST_CHECK_SMALL( geom.getProjectionAngleDegrees(2) - 114.59155902f, 1e-5f );

	BOOST_CHECK( geom.detectorOffsetToIndexFloat(0.0f) == 3.5f );
	BOOST_CHECK( geom.detectorOffsetToIndexFloat(0.625f) == 4.75f );
	BOOST_CHECK( geom.detectorOffsetToIndex(-0.1f) == 3 );

	BOOST_CHECK( geom.indexToDetectorOffset(0) == -1.75f );
	BOOST_CHECK( geom.indexToDetectorOffset(1) == -1.25f );

	int angle, detector;
	geom.indexToAngleDetectorIndex(10, angle, detector);
	BOOST_CHECK( angle == 1 );
	BOOST_CHECK( detector == 2 );
}

BOOST_AUTO_TEST_CASE( testParallelProjectionGeometry2D_Offsets_odd )
{
	std::vector<float> angles{ 0.0f, 1.0f, 2.0f, 3.0f };
	astra::CParallelProjectionGeometry2D geom(4, 7, 0.5f, std::move(angles));

	BOOST_REQUIRE( geom.isInitialized() );

	BOOST_CHECK( geom.detectorOffsetToIndexFloat(0.0f) == 3.0f );
	BOOST_CHECK( geom.detectorOffsetToIndexFloat(0.625f) == 4.25f );
}


BOOST_AUTO_TEST_CASE( testParallelProjectionGeometry2D_Clone )
{
	std::vector<float> angles{ 0.0f, 1.0f, 2.0f, 3.0f };
	astra::CParallelProjectionGeometry2D geom(4, 8, 0.5f, std::move(angles));

	BOOST_REQUIRE( geom.isInitialized() );

	astra::CProjectionGeometry2D* geom2 = geom.clone();

	BOOST_REQUIRE( geom2->isInitialized() );

	BOOST_CHECK( geom.isEqual(*geom2) );
	BOOST_CHECK( geom2->getProjectionAngleCount() == 4 );
	BOOST_CHECK( geom2->getDetectorCount() == 8 );
	BOOST_CHECK( geom2->getDetectorWidth() == 0.5f );
	BOOST_CHECK( geom2->getProjectionAngle(0) == 0.0f );
	BOOST_CHECK( geom2->getProjectionAngle(1) == 1.0f );
	BOOST_CHECK( geom2->getProjectionAngle(2) == 2.0f );
	BOOST_CHECK( geom2->getProjectionAngle(3) == 3.0f );
	BOOST_CHECK( geom2->getProjectionAngles()[0] == 0.0f );
	BOOST_CHECK( geom2->getProjectionAngles()[3] == 3.0f );
	delete geom2;
}

